package com.invest_elevate.FullscreenNavigation;

import com.invest_elevate.sip.sip1;
import com.invest_elevate.sip.sip2;
import com.invest_elevate.sip.sip3;
import com.invest_elevate.sip.sip4;

import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;

// import com.home.sectorpage.BankNifty;
// import com.home.sectorpage.ItPage;
// import com.home.sectorpage.NiftyPage;
// import com.home.sectorpage.Pharma;



public class HomePage extends Application {
    static String userName = "Kaushal";
    private static boolean isSidebarVisible = true;

    @Override
    public void start(Stage primaryStage) {

        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
        primaryStage.setX(primaryScreenBounds.getMinX());
        primaryStage.setY(primaryScreenBounds.getMinY());
        primaryStage.setWidth(primaryScreenBounds.getWidth());
        primaryStage.setHeight(primaryScreenBounds.getHeight());
        // Top Layout
        HBox topLayout = createTopLayout();

        // Sidebar Menu
        VBox sidebarMenu = createSidebarMenu();

        Button hiddenButton = new Button("Hidden Button");
        hiddenButton.setVisible(false); // Make the button invisible

        // Set the action for the hidden button
        hiddenButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Integer cardIndex = (Integer) hiddenButton.getUserData();
                sip1 bn = new sip1();
                sip3 n = new sip3();
                sip2 it = new sip2();
                sip4 p = new sip4();

                switch (cardIndex) {
                    case 1:
                        try {
                            bn.start(primaryStage);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 2:
                        try {
                            n.start(primaryStage);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        try {
                            it.start(primaryStage);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 4:
                        try {
                            p.start(primaryStage);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                }
            }
        });

        // Cards for events
        VBox card1 = createCard("Bank Nifty", "file:future_forge//src//main//resources//images//banknifty.jpeg", "0.2%", "₹664 Cr", "15.6%",
                hiddenButton, 1);
        VBox card2 = createCard("Nifty", "file:future_forge//src//main//resources//images//nifty.jpeg", "0.3%", "₹700 Cr", "12.3%",
                hiddenButton, 2);
        VBox card3 = createCard("IT", "file:future_forge//src//main//resources//images//it.jpeg","0.1%", "₹800 Cr", "18.9%", hiddenButton, 3);
        VBox card4 = createCard("Pharma", "file:future_forge//src//main//resources//images//pharma.jpeg", "0.4%", "₹900 Cr", "10.2%",
                hiddenButton, 4);

        // Grid for the cards
        GridPane centerGrid = createCardGrid(card1, card2, card3, card4);

        // Root layout
        BorderPane root = new BorderPane();
        root.setTop(topLayout);
        root.setLeft(sidebarMenu);
        root.setCenter(centerGrid);
        root.setPadding(new Insets(10));

        // Sidebar Toggle Button Action
        javafx.scene.Node firstChild = topLayout.getChildren().get(0);
        if (firstChild instanceof HBox) {
            HBox hbox = (HBox) firstChild;
            if (!hbox.getChildren().isEmpty() && hbox.getChildren().get(0) instanceof Button) {
                Button menuButton = (Button) hbox.getChildren().get(0);
                menuButton.setOnAction(e -> toggleSidebar(root, sidebarMenu));
            } else {
                // Handle the case where the expected structure is not as assumed
                System.err.println("Expected Button not found in HBox");
            }
        } else {
            // Handle the case where the first child of topLayout is not an HBox
            System.err.println("Expected HBox not found in topLayout");
        }

        // Adding responsive background image
        BackgroundImage backgroundImage = new BackgroundImage(
                new Image("file:future_forge//src//main//resources//images//house.png", Screen.getPrimary().getBounds().getWidth(),
                        Screen.getPrimary().getBounds().getHeight(), false, true),
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        root.setBackground(new Background(backgroundImage));

        // Scene and Stage
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("JavaFX Application");
        primaryStage.show();
    }

    private static void toggleSidebar(BorderPane root, VBox sidebarMenu) {
        TranslateTransition transition = new TranslateTransition(Duration.millis(300), sidebarMenu);
        if (isSidebarVisible) {
            transition.setToX(-sidebarMenu.getWidth());
            transition.setOnFinished(event -> root.setLeft(null));
        } else {
            root.setLeft(sidebarMenu);
            transition.setFromX(-sidebarMenu.getWidth());
            transition.setToX(0);
        }
        isSidebarVisible = !isSidebarVisible;
        transition.play();
    }

    private static HBox createTopLayout() {
        HBox topLayout = new HBox(10);
        topLayout.setPadding(new Insets(20));
        topLayout.setAlignment(Pos.CENTER_RIGHT);

        HBox topLeftSection = new HBox(10);
        topLeftSection.setAlignment(Pos.CENTER_LEFT);
        Button menuButton = new Button("☰ Menu");
        menuButton.setStyle("-fx-font-size: 14px; -fx-background-color: transparent;");

        Text companyLogoView = new Text("Invest \nElevate");
        companyLogoView.setStyle("-fx-text-fill: white;-fx-font-weight:bold;-fx-font-size:40");
        HBox.setMargin(companyLogoView, new Insets(0, 0, 0, 100));
        HBox logoHBox = new HBox(companyLogoView);

        ImageView profileImageView = new ImageView(new Image("file:future_forge//src//main//resources//images//user.png"));
        profileImageView.setFitHeight(30);
        profileImageView.setFitWidth(30);
        profileImageView.setPreserveRatio(true);
        profileImageView.setStyle("-fx-background-color: transparent;");
        HBox profileBox = new HBox(profileImageView);
        profileBox.setPadding(new Insets(5));

        Text message = new Text("Welcome " + userName);
        message.setStyle("-fx-text-fill: white;-fx-font-weight:bold;-fx-font-size:40");

        VBox userBox = new VBox(profileBox, message);
        userBox.setAlignment(Pos.CENTER_LEFT);
        userBox.setSpacing(5);

        TextField searchBox = new TextField();
        searchBox.setPromptText("Search...");
        searchBox.setStyle(
                "-fx-background-color: #fff; -fx-border-color: #ccc; -fx-padding: 10px; -fx-font-size: 14px;");
        searchBox.setPrefWidth(300);

        VBox searchBoxContainer = new VBox(searchBox);
        searchBoxContainer.setAlignment(Pos.BOTTOM_LEFT);
        searchBoxContainer.setPadding(new Insets(0, 0, 0, 0));

        HBox rightAlignBox = new HBox(20);
        rightAlignBox.setAlignment(Pos.CENTER_LEFT);
        rightAlignBox.getChildren().addAll(userBox, searchBoxContainer);

        topLayout.setStyle(
                "-fx-background-color: rgba(255,255,255,0.3); -fx-border-radius: 5; -fx-background-radius: 5;");
        topLayout.getChildren().addAll(menuButton, rightAlignBox, logoHBox);
        HBox.setHgrow(rightAlignBox, Priority.ALWAYS);

        return topLayout;
    }

    private static VBox createSidebarMenu() {
        VBox sidebarMenu = new VBox(25);
        sidebarMenu.setPadding(new Insets(40, 40, 25, 40));
        sidebarMenu.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7);-fx-border-radius: 5;-fx-background-radius: 5;");

        VBox topButtons = new VBox(15);
        Button dashboardButton = new Button("Dashboard");
        Button aboutUsButton = new Button("About Us");
        Button contactUsButton = new Button("Contact");

        dashboardButton.setMaxWidth(Double.MAX_VALUE);
        aboutUsButton.setMaxWidth(Double.MAX_VALUE);
        contactUsButton.setMaxWidth(Double.MAX_VALUE);

        topButtons.getChildren().addAll(dashboardButton, aboutUsButton, contactUsButton);

        VBox bottomButtons = new VBox(15);
        Button helpCenterButton = new Button("Help Center");
        Button settingsButton = new Button("Settings");
        Button logOutButton = new Button("Log out");
        helpCenterButton.setMaxWidth(Double.MAX_VALUE);
        settingsButton.setMaxWidth(Double.MAX_VALUE);
        logOutButton.setMaxWidth(Double.MAX_VALUE);
        bottomButtons.getChildren().addAll(helpCenterButton, settingsButton, logOutButton);

        Pane spacer = new Pane();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        sidebarMenu.getChildren().addAll(topButtons, spacer, bottomButtons);

        String buttonStyle = "-fx-font-size: 14px; -fx-background-color: #333; -fx-text-fill: white; -fx-border-color: #555; -fx-border-radius: 5; -fx-background-radius: 5;";
        dashboardButton.setStyle(buttonStyle);
        aboutUsButton.setStyle(buttonStyle);
        contactUsButton.setStyle(buttonStyle);
        helpCenterButton.setStyle(buttonStyle);
        settingsButton.setStyle(buttonStyle);
        logOutButton.setStyle(buttonStyle);

        logOutButton.setOnMouseEntered(e -> logOutButton.setStyle(
                "-fx-background-color: RED; -fx-font-size: 14px; -fx-text-fill: white; -fx-border-color: #555; -fx-border-radius: 5; -fx-background-radius: 5;"));
        logOutButton.setOnMouseExited(e -> logOutButton.setStyle(buttonStyle));

        return sidebarMenu;
    }

    private static GridPane createCardGrid(VBox... cards) {
        GridPane centerGrid = new GridPane();
        centerGrid.setHgap(30);
        centerGrid.setVgap(30);
        centerGrid.setPadding(new Insets(10, 40, 25, 30));

        centerGrid.add(cards[0], 0, 0);
        centerGrid.add(cards[1], 1, 0);
        centerGrid.add(cards[2], 0, 1);
        centerGrid.add(cards[3], 1, 1);

        // Make the cards equally divided and responsive
        for (VBox card : cards) {
            GridPane.setHgrow(card, Priority.ALWAYS);
            GridPane.setVgrow(card, Priority.ALWAYS);
            card.prefWidthProperty().bind(centerGrid.widthProperty().divide(2).subtract(30));
            card.prefHeightProperty().bind(centerGrid.heightProperty().divide(1.6).subtract(30));
        }

        return centerGrid;
    }

    private static VBox createCard(String title, String imagePath, String expenseRatio, String aum,
            String returns,
            Button hiddenButton, int i) {
        VBox card = new VBox(10);
        card.setAlignment(Pos.TOP_LEFT);
        card.setPadding(new Insets(15));
        card.setStyle(
                "-fx-background-color: rgba(240, 240, 240, 0.6); -fx-border-color: #B0B0B0; -fx-border-radius: 20; -fx-background-radius: 20;");

        ImageView imageView = new ImageView(new Image(imagePath));
        imageView.setPreserveRatio(true);
        imageView.fitWidthProperty().bind(card.widthProperty().divide(2));
        imageView.setFitHeight(150);
        imageView.setSmooth(true);

        // ImageView iconView = new ImageView(new Image(iconPath));
        // iconView.setPreserveRatio(true);
        // iconView.fitWidthProperty().bind(card.widthProperty().divide(2));
        // iconView.setFitHeight(150);
        // iconView.setSmooth(true);
        // HBox hicon = new HBox(iconView);
        // hicon.setAlignment(Pos.CENTER_RIGHT);
        // //iconView.setPadding(new Insets(50,0,50,100));

        Label titleLabel = new Label(title);
        titleLabel.setFont(new Font("Arial", 35));
        titleLabel.setTextFill(Color.BLACK);
        titleLabel.setAlignment(Pos.CENTER);
        titleLabel.setPadding(new Insets(10, 0, 0, 0));

        // Create labels for Expense Ratio, AUM, and 3Y Returns
        HBox expenseRatioBox = createInfoBox("Expense Ratio", expenseRatio);
        HBox aumBox = createInfoBox("AUM", aum);
        HBox returnsBox = createInfoBox("3Y Returns", returns, Color.GREEN);

        VBox infoBox = new VBox(10, expenseRatioBox, aumBox, returnsBox);
        infoBox.setPadding(new Insets(10, 0, 0, 0));

        // Add hover effect
        card.setOnMouseEntered(e -> card.setStyle(
                "-fx-background-color: rgba(255, 255, 255, 0.8); -fx-border-color: #B0B0B0; -fx-border-radius: 15; -fx-background-radius: 15;"));
        card.setOnMouseExited(e -> card.setStyle(
                "-fx-background-color: rgba(240, 240, 240, 0.6); -fx-border-color: #B0B0B0; -fx-border-radius: 15; -fx-background-radius: 15;"));

        // Set card click action
        card.setOnMouseClicked(event -> {
            hiddenButton.setUserData(i);
            hiddenButton.fire();
        });

        card.getChildren().addAll(imageView, titleLabel, infoBox);

        return card;
    }

    private static HBox createInfoBox(String label, String value) {
        return createInfoBox(label, value, Color.BLACK);
    }

    private static HBox createInfoBox(String label, String value, Color valueColor) {
        Label labelNode = new Label(label);
        labelNode.setFont(new Font("Arial", 17));
        labelNode.setTextFill(Color.GRAY);

        Label valueNode = new Label(value);
        valueNode.setFont(new Font("Arial", 17));
        valueNode.setTextFill(valueColor);
        valueNode.setStyle("-fx-font-weight: bold;");

        HBox infoBox = new HBox(10, labelNode, valueNode);
        infoBox.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(labelNode, Priority.ALWAYS);
        valueNode.setAlignment(Pos.CENTER_RIGHT);

        return infoBox;
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static Scene getHomePageScene(Stage primaryStage) {
        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
        primaryStage.setX(primaryScreenBounds.getMinX());
        primaryStage.setY(primaryScreenBounds.getMinY());
        primaryStage.setWidth(primaryScreenBounds.getWidth());
        primaryStage.setHeight(primaryScreenBounds.getHeight());
    
        // Top Layout
        HBox topLayout = createTopLayout();
    
        // Sidebar Menu
        VBox sidebarMenu = createSidebarMenu();
    
        Button hiddenButton = new Button("Hidden Button");
        hiddenButton.setVisible(false); // Make the button invisible
    
        // Set the action for the hidden button
        hiddenButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Integer cardIndex = (Integer) hiddenButton.getUserData();
                sip1 bn = new sip1();
                sip3 n = new sip3();
                sip2 it = new sip2();
                sip4 p = new sip4();
    
                switch (cardIndex) {
                    case 1:
                        try {
                            bn.start(primaryStage);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 2:
                        try {
                            n.start(primaryStage);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        try {
                            it.start(primaryStage);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 4:
                        try {
                            p.start(primaryStage);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                }
            }
        });
    
        // Cards for events
        VBox card1 = createCard("Bank Nifty", "file:future_forge//src//main//resources//images//banknifty.jpeg", "0.2%", "₹664 Cr", "15.6%",
                hiddenButton, 1);
        VBox card2 = createCard("Nifty", "file:future_forge//src//main//resources//images//nifty.jpeg", "0.3%", "₹700 Cr", "12.3%",
                hiddenButton, 2);
        VBox card3 = createCard("IT", "file:future_forge//src//main//resources//images//it.jpeg","0.1%", "₹800 Cr", "18.9%", hiddenButton, 3);
        VBox card4 = createCard("Pharma", "file:future_forge//src//main//resources//images//pharma.jpeg", "0.4%", "₹900 Cr", "10.2%",
                hiddenButton, 4);
    
        // Grid for the cards
        GridPane centerGrid = createCardGrid(card1, card2, card3, card4);
    
        // Root layout
        BorderPane root = new BorderPane();
        root.setTop(topLayout);
        root.setLeft(sidebarMenu);
        root.setCenter(centerGrid);
        root.setPadding(new Insets(10));
    
        // Sidebar Toggle Button Action
        javafx.scene.Node firstChild = topLayout.getChildren().get(0);
        if (firstChild instanceof HBox) {
            HBox hbox = (HBox) firstChild;
            if (!hbox.getChildren().isEmpty() && hbox.getChildren().get(0) instanceof Button) {
                Button menuButton = (Button) hbox.getChildren().get(0);
                menuButton.setOnAction(e -> toggleSidebar(root, sidebarMenu));
            } else {
                // Handle the case where the expected structure is not as assumed
                System.err.println("Expected Button not found in HBox");
            }
        } else {
            // Handle the case where the first child of topLayout is not an HBox
            System.err.println("Expected HBox not found in topLayout");
        }
    
        // Adding responsive background image
        BackgroundImage backgroundImage = new BackgroundImage(
                new Image("file:future_forge//src//main//resources//images//house.png", Screen.getPrimary().getBounds().getWidth(),
                        Screen.getPrimary().getBounds().getHeight(), false, true),
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        root.setBackground(new Background(backgroundImage));
    
        // Scene
        Scene scene = new Scene(root, primaryScreenBounds.getWidth(), primaryScreenBounds.getHeight());
        return scene;
    }
    
}

