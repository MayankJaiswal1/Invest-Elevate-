package com.invest_elevate;

import com.invest_elevate.firestore.initialize.initializeApp;

import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Application.launch(initializeApp.class, args);
    }
}